const express = require('express');
const bodyParser = require('body-parser');
const moment = require('moment');

const app = express();
const port = 3000;

// Middleware to serve static files
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

// Endpoint to handle form submission
app.post('/calculate', (req, res) => {
  const birthdate = req.body.birthdate;

  if (!moment(birthdate, 'YYYY-MM-DD', true).isValid()) {
    res.send('Invalid date format. Please use YYYY-MM-DD.');
    return;
  }

  const nextBirthday = calculateNextBirthday(birthdate);
  res.send(`Your next birthday is on: ${nextBirthday.format('YYYY-MM-DD')}`);
});

// Function to calculate next birthday
function calculateNextBirthday(birthdate) {
  const today = moment();
  let nextBirthday = moment(birthdate).year(today.year());

  if (nextBirthday.isBefore(today, 'day')) {
    nextBirthday = nextBirthday.add(1, 'year');
  }

  return nextBirthday;
}

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});